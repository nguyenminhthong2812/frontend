# những lưu ý khi chạy source code
B1: chạy lệnh => npm install (lệnh này cài đặt tất cả thư viện vào node_modules)
B2: start server => ng serve --open